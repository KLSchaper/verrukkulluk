<?php

namespace ManKind;

abstract class ModelManager
{
    private static array $models = [];
    private static array $model_info = [];
    //=========================================================================
    // route getXXXDAO function calls to self::getModel(self::$model_info[XXX])
    //=========================================================================
    public static function __callStatic(string $name, array $arguments): mixed
    {
        $model = substr($name, 3); //trim 'get'
        if (isset(self::$model_info[$model])) {
            return self::getModel(self::$model_info[$model]);
        }
        throw new \Exception('ModelManager - unknown static method call ['
            . $name . ']');
    }

    //=========================================================================
    // input : array ModelName => <namespace/>ModelClass
    //=========================================================================
    public static function registerModels(array $model_info)
    {
        self::$model_info = $model_info;
    }

    //=========================================================================
    // singleton pattern implementation per model
    //=========================================================================
    private static function getModel(
        string $modelclass
    ): \vrklk\base\model\BaseDAO {
        if (isset(self::$models[$modelclass]) === false) {
            self::$models[$modelclass] = new $modelclass();
        }
        return self::$models[$modelclass];
    }
}
