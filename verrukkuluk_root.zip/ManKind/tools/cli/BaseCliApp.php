<?php
namespace ManKind\tools\cli;
abstract class BaseCliApp 
{
    protected string $app;
    protected array|bool $params;
    protected bool $interactive; //TRUE then Ask userinput for missing params
    protected CliOptionParser $parser;
//==============================================================================	
    public function __construct(string $app, bool $interactive, array $argv)
    {
        $this->app = $app;
        $this->interactive = $interactive;
        \ManKind\tools\dev\Logger::_dump('ARGV',$argv);
    }
//==============================================================================	
    public function run()
    {
        try 
        {
            $this->_createParser();
            $this->_setOptions();
            $this->params = $this->parser->getOptionValues();
            if ($this->params !== false) 
            {
                $this->_doYourTask();
            }
            else
            {
                $this->parser->showUsage();
            }
        }			
        catch (\Throwable $ex) 
        {
            \ManKind\tools\dev\Logger::_error($ex);
        }
    }
//=============================================================================	
    protected function _createParser() : void
    {
        $this->parser = $this->interactive 
                      ? new CliOptionGetter() //Parser();
                      : new CliOptionParser(); //Parser();
    }    
//=============================================================================	
    protected function _getParam(string $name) : mixed
    {
        return isset($this->params[$name])
               ? $this->params[$name]
               : null;
    }
//=============================================================================	
    abstract protected function _setOptions();
    abstract protected function _doYourTask();
//==============================================================================	
}
