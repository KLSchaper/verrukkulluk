<?php
namespace ManKind\tools\cli;
enum CliColor : string
{
    case Black          = '0;30';
    case DarkGrey       = '1;30';
    case Red            = '0;31';
    case LightRed       = '1;31';
    case Green          = '0;32';
    case LightGreen     = '1;32';
    case Brown          = '0;33';
    case Yellow         = '1;33';
    case Blue           = '0;34';
    case LightBlue      = '1;34';
    case Magenta        = '0;35';
    case LightMagenta   = '1;35';
    case Cyan           = '0;36';
    case LightCyan      = '1;36';
    case LightGrey      = '0;37';
    case White          = '1;37';
}    

