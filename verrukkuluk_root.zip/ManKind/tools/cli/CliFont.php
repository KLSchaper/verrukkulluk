<?php
namespace ManKind\tools\cli;
enum CliFont : string
{
    case Bold           = '1';
    case Italic         = '3';
    case Underline      = '4';
    case Blink          = '5'; 
    case Reverse        = '7'; 
    case Hidden         = '8';
}    
