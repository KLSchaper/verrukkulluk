<?php
namespace ManKind\tools\cli;
/*       \|||/            +++            /@@@\             
        @(o o)@          (0_0)          /(^ ^)\
  ,--ooO--(_)---------ooo-----ooo---------\-/---Ooo----,
  |                        	                       |
  | class     CliOptionGetter                          |
  | @author   geert                                    |
  | @date     20.01.2023                               |
  |  	                                               |
  '-------------Ooo--------------------ooO-------------'
        |__|__|         ooO Ooo        /_______\
  %      || ||      %   %    %   %       || ||     %
  \|/___ooO Ooo____\|/_\|/__\|/_\|/_____ooO Ooo___\|/ */
require_once 'CliOptionParser.php';
class CliOptionGetter extends CliOptionParser
{
//==============================================================================    
    protected function validateCliValue(array $option, mixed $value) : bool
    {
        if ($option[self::OPT_TYPE]->validType($value))
        {
            $this->values[$option[self::OPT_NAME]] = $option[self::OPT_TYPE]->castToType($value);
        }
        else
        {
            $this->values[$option[self::OPT_NAME]] = $this->getUserInput($option);
        }
        return true;
    }    
//==============================================================================    
    protected function getUserInput(array $option) : mixed
    {
        do
        {
            echo $option[self::OPT_DESCR]."(".$option[self::OPT_TYPE]->value."): ";
            $input = fgets(STDIN);
            //$value = readLine($option[self::OPT_DESCR]."(".$option[self::OPT_TYPE]->value."): ");
            if ($input===false) //(Ctrl-`C)
            {
                die('Aborted by user..');
            } 
            $value = str_replace(PHP_EOL,'', $input);
        }   
        while (!$option[self::OPT_TYPE]->validType($value));
        return $option[self::OPT_TYPE]->castToType($value);
    }    
}
