<?php
namespace ManKind\tools\cli;
/*       \|||/            +++            /@@@\             
        @(o o)@          (0_0)          /(^ ^)\
  ,--ooO--(_)---------ooo-----ooo---------\-/---Ooo----,
  |                        	                       |
  | class     CliOptionParser                          |
  | @author   geert                                    |
  | @date     18.01.2023                               |
  |  	                                               |
  '-------------Ooo--------------------ooO-------------'
        |__|__|        ooO Ooo         /_______\
   %     || ||      %   %    %   %       || ||     %
  \|/___ooO Ooo____\|/_\|/__\|/_\|/_____ooO Ooo___\|/ */
class CliOptionParser
{
    const OPT_NAME = 0;
    const OPT_TYPE = 1;
    const OPT_REQ  = 2;
    const OPT_DEF  = 3;
    const OPT_DESCR= 4;

    protected array $options=[];
    protected array $errors=[];
    protected array $values=[];
//==============================================================================
    public function addOption(
        string $name, 
        CliOptionType $type, 
        bool $required, 
        string $descr='', 
        string|int|float|bool $default=null
    ) : bool
    {
        return array_push(
            $this->options, 
            [
                self::OPT_NAME => $name, 
                self::OPT_TYPE => $type, 
                self::OPT_REQ => $required,
                self::OPT_DESCR => $descr,
                self::OPT_DEF => $default
            ]
        ) > 0;
    }
//==============================================================================
    public function showUsage() : void
    {
        echo "\033[37;44m 💁 \033[1mUsage  : \33[0m".PHP_EOL;
        foreach ($this->options as $o)
        {
            $name = $o[self::OPT_NAME];
            $prefix=strlen($name)===1?'-':'--';
            echo "\033[1m".$prefix.$name." \033[3m(".$o[self::OPT_TYPE]->value.")\033[0m ";
            if ($o[self::OPT_TYPE] === CliOptionType::OPT_NOVALUE)
            {
                echo 'optional';
            }    
            else
            {
                echo $o[self::OPT_REQ]===false
                    ? 'optional'.' default ['.$o[self::OPT_DEF].']'
                    : 'required';
            }    
            echo ' => '.$o[self::OPT_DESCR].PHP_EOL;
        }	
    }
//==============================================================================
    public function getOptionValues() : array|false
    {
        $this->errors = [];
        if ($this->parseCliOptions() && $this->validateCliValues())
        {
            return $this->values;
        }  
        $this->showErrors();
        return false;
    }    
//==============================================================================
    protected function parseCliOptions() : bool
    {
        try
        {
            $short = '';
            $long = [];
            foreach ($this->options as $o)
            {
                $name = $o[self::OPT_NAME];
                $is_short = strlen($name)===1;

                if ($o[self::OPT_TYPE] !== CliOptionType::OPT_NOVALUE)
                {
                        $name .= $o[self::OPT_REQ]?':':'::';
                }				
                $is_short ? $short .= $name : array_push($long, $name);
            }
            $this->values = getopt($short, $long);
            return true;
        }
        catch (Throwable $t)
        {
            array_push($this->errors, $t->getMessage());
            return false;
        }
    }
//==============================================================================
    protected function validateCliValues() : bool
    {    
        try
        {
            foreach ($this->options as $o)
            {
                $value = $this->getCliValue($o);
                $this->validateCliValue($o, $value);
            }
            return (count($this->errors)===0);
        }
        catch (Throwable $t)
        {
            array_push($this->errors, $t->getMessage());
            return false;
        }
    }	
//==============================================================================
    protected function getCliValue(array $option) : mixed
    {
        if (isset($this->values[$option[self::OPT_NAME]]))
        {
//No value type, en gezet, dan TRUE als value
//Andere types meegegeven value        
            
            $value = ($option[self::OPT_TYPE]===CliOptionType::OPT_NOVALUE)
                   ? true
                   : $this->values[$option[self::OPT_NAME]];
        }
//No value type, en niet gezet, dan FALSE als value        
        elseif ($option[self::OPT_TYPE]===CliOptionType::OPT_NOVALUE)
        {
            $value=false;
        }	
        else 
        {
// Niet meegegeven en verplicht, dan null anders default-optie-waarde
            $value = $option[self::OPT_REQ]
                   ? null
                   : $option[self::OPT_DEF];
        }
        return $value;
    }    
//==============================================================================
// enum aan het werk als class!
// note : return wordt nu niet gebruikt, maar voor mogelijke extends wel handig.    
//==============================================================================
    protected function validateCliValue(array $option, mixed $value) : bool
    {
        if ($option[self::OPT_TYPE]->validType($value))
        {
            $this->values[$option[self::OPT_NAME]] = $option[self::OPT_TYPE]->castToType($value);
            return true;
        }
        else
        {
            array_push(
                $this->errors, 
                'Missing or invalid '
                .$option[self::OPT_TYPE]->value
                .'-value for option ['
                .$option[self::OPT_NAME].']'
            ); 
            return false;
        }		
    }    
//==============================================================================
    protected function showErrors() : void
    {
        echo "\033[41;37m ☠ \033[1mOops : \033[0;31m".PHP_EOL;
        foreach ($this->errors as $error)
        {
            echo '⚠ '.$error.PHP_EOL;
        } 
        echo "\033[0m";
    }
//==============================================================================
}
