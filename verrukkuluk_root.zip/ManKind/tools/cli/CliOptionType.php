<?php
namespace ManKind\tools\cli;
/*       \|||/            +++            /@@@\             
        @(o o)@          (0_0)          /(^ ^)\
  ,--ooO--(_)---------ooo-----ooo---------\-/---Ooo----,
  |                                                    |
  | enum      CliOptionType                            |
  | @author   geert                                    |
  | @date     18.01.2023                               |
  | More info https://stitcher.io/blog/php-enums       |
  |	                                               |
  '-------------Ooo--------------------ooO-------------'
         |__|__|        ooO Ooo         /_______\
   %      || ||      %   %    %   %       || ||     %
  \|/____ooO Ooo____\|/_\|/__\|/_\|/_____ooO Ooo___\|/ */
enum CliOptionType : string
{
    case OPT_STRING = 'String';
    case OPT_INT    = 'Integer';
    case OPT_FLOAT  = 'Float';
    case OPT_NOVALUE= 'Switch';
//==============================================================================
    public function validType(mixed $value): bool
    {
        return match($this) 
        {	
            self::OPT_STRING  	=> is_string($value),   
            self::OPT_INT  	=> ctype_digit(strval($value)),   
            self::OPT_FLOAT 	=> is_numeric($value),   
            self::OPT_NOVALUE 	=> is_bool($value),
        };
    }	
//==============================================================================
    public function castToType(mixed $value): mixed
    {
        return match($this) 
        {	
            self::OPT_STRING  	=> strval($value),   
            self::OPT_INT  	=> (int) $value,   
            self::OPT_FLOAT 	=> (float) $value,   
            self::OPT_NOVALUE 	=> $value,
        };
    }	
}
