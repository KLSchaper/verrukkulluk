<?php
namespace ManKind\tools\cli;

/*       \|||/            +++            /@@@\             
        @(o o)@          (0_0)          /(^ ^)\
  ,--ooO--(_)---------ooo-----ooo---------\-/---Ooo----,
  |                        	                       |
  | class     CliText                                  |
  | @author   geert                                    |
  | @date     21.01.2023                               |
  |  	                                               |
  '-------------Ooo--------------------ooO-------------'
        |__|__|         ooO Ooo        /_______\
   %     || ||      %   %    %   %       || ||     %
  \|/___ooO Ooo____\|/_\|/__\|/_\|/_____ooO Ooo___\|/ */
class CliText
{
    const SEQ_B = "\033"; //Octal notiation for Esc = Chr(27)
    const SEQ_E = "m";    
    

    public static function reset() : string
    {
        return self::SEQ_B."[0".self::SEQ_E;
    }
    
    public static function font(CliFont $font) : string
    {
        return self::SEQ_B."[".$font->value.self::SEQ_E;
    }
    
    public static function color(CliColor $color) : string
    {
        return self::SEQ_B."[".$color->value.self::SEQ_E;
    }    
    
    public static function colorOnColor(CliColor $fore, CliBkColor $back) : string
    {
        return self::SEQ_B."[".$fore->value.";".$back->value.self::SEQ_E;
    }    
}
