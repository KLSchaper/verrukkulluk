<?php
namespace ManKind\tools\cli;
class DbCliApp extends BaseCliApp
{
    protected ? \ManKind\tools\interfaces\iCrud $_crud   = null; 
//==============================================================================
    protected function _setOptions()
    {
        $this->parser->addOption(
            name    : 'driver', 
            type    : CliOptionType::OPT_STRING, 
            required: false,
            descr   : 'PDO Driver',
            default : 'mysql'
        ); 
        $this->parser->addOption(
            name    : 'host', 
            type    : CliOptionType::OPT_STRING, 
            required: false,
            descr   : 'PDO Host',
            default : '127.0.0.1'
        ); 
        $this->parser->addOption(
            name    : 'user', 
            type    : CliOptionType::OPT_STRING, 
            required: true,
            descr   : 'PDO User'
        ); 
        $this->parser->addOption(
            name    : 'pass', 
            type    : CliOptionType::OPT_STRING, 
            required: true,
            descr   : 'PDO Password'
        ); 
        $this->parser->addOption(
            name    : 'db', 
            type    : CliOptionType::OPT_STRING, 
            required: true,
            descr   : 'Database'
        ); 
    }
//==============================================================================    
    protected function _doYourTask()
    {
        if ($this->_makeConnection()===false)
        {
            die("\033[41;37m ☠ \033[1mNo connnection\033[0;31m".PHP_EOL);
        }
        echo "Connected.".PHP_EOL;
    }        
//=============================================================================	
    private function _makeConnection() : bool
    {
        echo "Connecting to ".$this->_getParam('db').PHP_EOL;
        $conn = new \PDO(
            $this->_getParam('driver')
            .":host=".$this->_getParam('host')
            .";dbname=".$this->_getParam('db')
            ,$this->_getParam('user')
            , \ManKind\tools\dev\Tools::garble( 
                $this->_getParam('pass'), 
                \Config::MYKEY
            )
        );
        $conn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        $this->_crud = \ManKind\tools\pdo\Crud::getInstance($conn);
        return $this->_crud instanceof \ManKind\tools\interfaces\iCrud; 
    }
    
//==============================================================================
}