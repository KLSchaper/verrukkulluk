<?php
################################################################################
# Author        : M@nKind - Geert Weggemans 
# Date 		: 26-08-2015
# Function      : Generic autoloader 
#                 maps class SomeClassName to file some_class_name.php  
# Dependency    : $namespace array with namespace -> base-folder -items
#                 must be declared!                
################################################################################
namespace tools\dev;
class AutoLoader
{
    protected static $registered = 0;
    protected static $namespaces = [];
    
    public function __construct($namespaces = [])
    {
        self::init($namespaces);
    }
//==============================================================================    
    public static function init($namespaces = [])
    {
        if ($namespaces)
        {
            self::_addNameSpaces($namespaces);
        }
        if (self::$registered===0)
        {
            spl_autoload_register(__CLASS__.'::autoLoad');
            self::$registered++;
        }   
    }
//==============================================================================    
    public static function autoLoad($class)
    {
        foreach (self::$namespaces as $namespace => $info)
        {    
            $len = strlen($namespace);
            if (strncmp($namespace, $class, $len) !== 0)
            {
                continue;
            }
            $relative_class = substr($class, $len+1);
            if (is_array($info))
            {
                $base_dir = $info['base_dir'];
                if ($info['underscore_naming'])
                {
                   $relative_class = strtolower(preg_replace('/([a-z,0-9])([A-Z,0-9])/', '\1_\2' , $relative_class)); 
                }
            }
            else
            {
                $base_dir = $info;
                
            }
            $relative_class = str_replace('\\', DIRECTORY_SEPARATOR, $relative_class).'.php';
            if (self::_loadFile($base_dir
                                .DIRECTORY_SEPARATOR
                                .$relative_class))
            {
                return TRUE;
            }
            else 
            {
                $maps = array_filter(glob($base_dir.DIRECTORY_SEPARATOR.'*'         ), 'is_dir');
                foreach ($maps as $map)
                {
                    //echo $map.PHP_EOL;
                    if (self::_loadFile(//$base_dir
                                        //.DIRECTORY_SEPARATOR
                                        //.
                                        $map
                                        .DIRECTORY_SEPARATOR
                                        .$relative_class))
                    {
                        return TRUE;
                    }
                }
            }
            Logger::_echo($relative_class.' not found!');
            return FALSE;
        }
    }
//==============================================================================    
    protected static function _addNameSpaces($namespaces)
    {
        if (count($namespaces)>1)
        {
            self::$namespaces = array_merge(self::$namespaces, $namespaces);
        }
        else 
        {
            self::$namespaces[] = $namespaces;
        }
    }
//==============================================================================
    protected static function _loadFile(string $filename) : bool
    {
        //echo '<p>try to load ['.$filename.']</p>';
        if (file_exists($filename))
        {
            require_once $filename;
            return TRUE;
        }
        return FALSE;
    }
//==============================================================================
}
