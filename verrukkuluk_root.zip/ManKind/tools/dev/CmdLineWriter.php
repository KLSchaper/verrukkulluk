<?php
################################################################################
# Author	: M@nKind - Geert Weggemans  
# Date 		: 12-01-2012
# Desc		: Base Logging class
################################################################################
namespace ManKind\tools\dev;
use ManKind\tools\cli as CLI;
class CmdlineWriter implements \ManKind\tools\interfaces\iLogWriter
{
    public function _echo(string $msg) : void
    {
        echo $msg.PHP_EOL;
    }
//==============================================================================
    public function _dump(string $name, mixed $var) : void
    {   
        echo CLI\CliText::font(CLI\CliFont::Bold).$name.CLI\CliText::reset().PHP_EOL;
        is_array($var) ? print_r($var) : var_dump($var);
        echo PHP_EOL;
    }
//==============================================================================
    public function _error(\Throwable $e) : void
    {   
        echo CLI\CliText::colorOnColor(CLI\CliColor::White,CLI\CliBkColor::Red)
            .' ☠ Error '.$e->getCode().' '
            .CLI\CliText::color(CLI\CliColor::Red).PHP_EOL    
            .'File '.$e->getFile()
            .' Line '.$e->getLine().PHP_EOL
            .$e->getMessage().CLI\CliText::reset().PHP_EOL;    
    }
}


