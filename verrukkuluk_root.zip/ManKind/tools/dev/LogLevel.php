<?php
namespace ManKind\tools\dev;
class LogLevel
{
    const LVL_EMERGENCY = 0x01;
    const LVL_ALERT     = 0x02;
    const LVL_CRITICAL  = 0x04;
    const LVL_ERROR     = 0x08;
    const LVL_WARNING   = 0x10;
    const LVL_NOTICE    = 0x20;
    const LVL_INFO      = 0x40;
    const LVL_DEBUG     = 0x80;
    const LVL_ALLWAYS   = 0xFF;
}