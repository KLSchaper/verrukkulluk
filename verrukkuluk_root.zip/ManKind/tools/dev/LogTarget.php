<?php
namespace ManKind\tools\dev;
class LogTarget
{
    const TO_LOG  = 0x01; //0000 0001
    const TO_SCR  = 0x02; //0000 0010
    const TO_ME   = 0x04; //0000 0100
    const TO_CMDLINE = 0x08; //0000 0100
}
