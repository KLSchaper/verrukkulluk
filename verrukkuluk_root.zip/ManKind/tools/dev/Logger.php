<?php
namespace ManKind\tools\dev;

################################################################################
# Author	: M@nKind - Geert Weggemans  
# Date 		: 12-01-2012
# Desc		: Base Logging class
################################################################################
class Logger
{
    public static string $logpath = '.\logs\\' ;
    public static int $level  = LogLevel::LVL_ALLWAYS;
    private static int $target = LogTarget::TO_LOG;
    private static ?array $writers = null;
//==============================================================================
    public function __construct(string $logpath, int $logtarget, int $loglevel)
    {
        self::init($logpath,$logtarget,$loglevel);
    }
//==============================================================================
    public static function init(string $logpath, int $logtarget, int $loglevel) : void
    {
        self::$logpath = $logpath;
        self::$writers = null;
        self::$target = $logtarget;
        self::$level = $loglevel;
    }        
//==============================================================================	
    public static function hasTarget(int $target) : bool 
    {
        return  (self::$target & $target) == $target;
    }    
//==============================================================================
    public static function _error(\Throwable $e, int $level=LogLevel::LVL_ALLWAYS) : void
    {
        if (($level & self::$level) == $level)
        {    
            foreach (self::getWriters() as $writer)
            {    
                $writer->_error($e);
            }        
        }    
    }    
//==============================================================================
    public static function _dump(string $name, $var, int $level=LogLevel::LVL_ALLWAYS) : void
    {
        if (($level & self::$level) == $level)
        {    
            foreach (self::getWriters() as $writer)
            {    
                $writer->_dump($name, $var);
            }        
        }    
    }	
//==============================================================================
    public static function _echo(string $msg, int $level=LogLevel::LVL_ALLWAYS) : void
    {
        if (($level & self::$level) == $level)
        {    
            foreach (self::getWriters() as $writer)
            {    
                $writer->_echo($msg);
            }        
        }    
    }	
//==============================================================================
    private static function getWriters() : array
    {
        if (is_null(self::$writers))
        {    
            self::$writers = [];
            if (self::hasTarget(LogTarget::TO_LOG))
            {
                self::$writers[] = new LogFileWriter(self::$logpath);
            }  
            if (self::hasTarget(LogTarget::TO_SCR))
            {
                self::$writers[] = new ScreenWriter(true);
            }    
            else 
            {
                if (self::hasTarget(LogTarget::TO_CMDLINE))
                {
                    self::$writers[] = new CmdlineWriter(false);
                }    
            }
            if (self::hasTarget(LogTarget::TO_ME))
            {
                //TO DO !! self::$writers[] = new Mailer();
            }  
        }    
        return self::$writers;
    }        
//==============================================================================	
}