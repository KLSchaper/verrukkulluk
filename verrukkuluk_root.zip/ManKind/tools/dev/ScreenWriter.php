<?php
################################################################################
# Author	: M@nKind - Geert Weggemans  
# Date 		: 12-01-2012
# Desc		: Base Logging class
################################################################################
namespace ManKind\tools\dev;
class ScreenWriter implements \ManKind\tools\interfaces\iLogWriter
{
    public function _echo(string $msg) : void
    {
        echo '<pre>'.$msg.'</pre>';
    }
//==============================================================================
    public function _dump(string $name, mixed $var) : void
    {   
        echo '<h3>'.$name.'</h3><pre>';
        is_array($var) ? print_r($var) : var_dump($var);
        echo '</pre>';
    }
//==============================================================================
    public function _error(\Throwable $e) : void
    {   
        echo '<div class="error">'
            .'  <h3>Error ['.$e->getCode().']</h3>'
            .'  <p>File = ['.$e->getFile().']</p>'
            .'  <p>Line = ['.$e->getLine().']</p>'
            .'  <p>Msg = '.$e->getMessage().']</p>'
            .'</div>';    
    }
}


