<?php
namespace ManKind\tools\file;
class FileUtils
{
//==============================================================================
    public static function getFileExt($filename) :string
    {
        return preg_match('/\./', $filename) ? preg_replace('/^.*\./', '', $filename) : '';
    }
//=============================================================================	
    public static function stripFileExt($filename) : string
    {
        return preg_replace('/.[^.]*$/', '', $filename);
    }   
//==============================================================================	
    public static function changeFileExt($filename, $ext) : string
    {
        return preg_replace('/.[^.]*$/', '.'.$ext, $filename);
    }   
//==============================================================================	
    public static function isImageFile($filename) : bool
    {
        return preg_match('/\.(bmp|gif|jpg|jpeg|png)$/i', $filename);
    }
//==============================================================================	
}
