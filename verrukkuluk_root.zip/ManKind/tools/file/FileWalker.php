<?php
namespace ManKind\tools\file;
class FileWalker
{
    protected int $foldercount = 0;
    protected int $filecount = 0;
    protected int $depth=-1;
//==============================================================================	
    public function useSomeForce(string $folder) : bool
    {
        $this->foldercount = 0;
        $this->filecount = 0;
        $this->depth = -1;
        return $this->scanFolder(0, realpath($folder));
    }
//==============================================================================	
    protected function scanFolder(int $parent, string $folder) : bool
    {
        if (chdir($folder))
        {
            $result = true;
            $this->depth++;
            $this->foldercount++;
            $folder_id = $this->openFolder($parent, $folder);
            $files = $this->getFiles();
            if ($files)
            {    
                sort($files);
                foreach ($files as $file)
                {
                    $this->filecount++;
                    $this->handleFile($folder_id, $file);
                }
            }    
            $folders = $this->getFolders();
            if ($folders)
            {    
                sort($folders);
                foreach ($folders as $folder)
                {
                    if ($this->scanFolder($folder_id, $folder)===false)
                    {
                        $result = false;
                        break;
                    }        
                }
            }    
            $this->closeFolder();
            chdir("..");	
            $this->depth--;
            return $result;
        }
        return false;
    }
//==============================================================================	
    protected function handleFile(int $parent, string $fn) :  int|false
    {
        echo '<li>INSERT FILE parent=['.$parent.'] id['.$this->filecount.'] file=['.$fn.']</li>'.PHP_EOL;
        return $this->filecount;
    }
//==============================================================================	
    protected function openFolder(int $parent, string $fn) :  int|false
    {
        echo '<li>INSERT FOLDER parent=['.$parent.'] id['.$this->foldercount.'] folder=['.$fn.']</li>'.PHP_EOL;
        echo '<ol>'.PHP_EOL;
        return $this->foldercount;
    }
//==============================================================================	
    protected function closeFolder() :  void
    {
        echo '</ol>'.PHP_EOL;
    }
//==============================================================================	
    protected function getFiles() : array|false
    {
        return array_filter(glob('*.*'), 'is_file');
    }
//==============================================================================	
    protected function getFolders() : array|false
    {
        return array_filter(glob('*'), 'is_dir');
    }
//==============================================================================	
}	
