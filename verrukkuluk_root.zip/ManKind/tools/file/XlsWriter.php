<?php
################################################################################
# Author	: M@nKind - Geert Weggemans 
# Date 		: 23-07-2012
# App		: UI Admin Base
# Class		: Excell writer
################################################################################
namespace ManKind\tools\file;
class xlsWriter
{ 
//==============================================================================
	public function begin() 
	{
		return pack("ssssss", 0x809, 0x8, 0x0, 0x10, 0x0, 0x0);
	}
//==============================================================================
	public function end() 
	{
		return pack("ss", 0x0A, 0x00);
	}
//==============================================================================
	public function numCell($row, $col, $val) 
	{
		return pack("sssss", 0x203, 14, $row, $col, 0x0).pack("d", $val);
	}
//==============================================================================
	public function textCell($row, $col, $val) 
	{
                $v = utf8_decode($val);
		$len = strlen($v);
		return pack("ssssss", 0x204, 8 + $len, $row, $col, 0x0, $len).$v;
	}
//==============================================================================
	public function httpHeader($downloadfilename)
	{
		header("Pragma: public");
		header("Expires: 0");
		header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");;
		header("Content-Disposition: attachment;filename=".$downloadfilename.".xls ");
		header("Content-Transfer-Encoding: binary ");
	}
} 