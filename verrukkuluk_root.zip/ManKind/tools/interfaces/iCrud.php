<?php
/**
 * Crud interface
 *
 * @author Geert Weggemans - geert@man-kind.nl
 * @date jan 8 2020
 */
namespace ManKind\tools\interfaces;
interface iCrud
{
    public function isConnected() : bool;
    public function getLastError() : string;
    public function beginTransaction() : bool;
    public function rollBack() : bool;
    public function commit() : bool;
    public function selectOne( string $sql, array $params=[], string $class='') : array|object|false;
    public function selectMore(string $sql, array $params=[], string $class='') : array|false;
    public function doInsert(  string $sql, array $params=[]) : int|false;
    public function doUpdate(  string $sql, array $params=[]) : int|false;
    public function doDelete(  string $sql, array $params=[]) : int|false;
    public function getDBTables() : array |false;
    public function getDBColumnsByTableName(string $tablename) : array |false;
}