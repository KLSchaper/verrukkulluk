<?php     
namespace ManKind\tools\interfaces;
interface iLogWriter
{
    public function _echo(string $msg) : void; 
    public function _dump(string $name, mixed $var) : void;
    public function _error(\Throwable $e) : void;
}
