<?php
namespace ManKind\tools\pdo;
use PDO, PDOStatement, PDOException;
class Crud implements \ManKind\tools\interfaces\iCrud, \ManKind\tools\interfaces\iLastError
{
    protected static $_instance = null;
    
    const PARAM_VALUE = 0;
    const PARAM_TYPE = 1;
    protected int $column = 0;
    protected PDO $db;
    protected PDOStatement $stmt;

    use \ManKind\tools\traits\tLastError;

    public static function getInstance(?PDO $conn=null)//: \ManKind\tools\interfaces\iCrud
    {
        $class = get_called_class(); 
        if (is_null(static::$_instance))
        {
            static::$_instance = new $class($conn);
        }
        return static::$_instance;
    }
//=============================================================================
    public function __clone() 
	{
        throw new \Error('Cloning '. get_called_class() .' is not allowed.');
    }
//=============================================================================
    public function __wakeup() 
	{
        throw new \Error('Unserializing '. get_called_class() .' is not allowed.');
    }    
//==============================================================================
    public function isConnected() : bool
    {
        return is_object($this->db);
    }
//==============================================================================	
    public function beginTransaction() : bool
    {
        return $this->db->beginTransaction();
    }
//==============================================================================	
    public function rollBack() : bool
    {
        return $this->db->rollBack(); 
    }
//==============================================================================	
    public function commit() : bool
    {
        return $this->db->commit();
    }
//==============================================================================
    public function truncateTables(array $tables) : bool
    {
        if ($this->db->query('SET FOREIGN_KEY_CHECKS=0')===false) 
        {
            return false;
        }
        $result = false;
        try
        {
            foreach ($tables as $table)
            {
                $sql = 'TRUNCATE TABLE '.$table;
                $stmt = $this->db->prepare($sql);
                if ($stmt)
                {
                    if ($stmt->execute())
                    {
                        \ManKind\tools\dev\Logger::_echo('['.$table.'] truncated');
                    }
                    else 
                    {
                        $result=false;
                        $this->_setLastError('1001:Unable to execute truncate ['.$table.']');
                        break;
                    }
                }
                else 
                {
                    $result=false;
                    $this->_setLastError('1001:Unable to create truncate ['.$table.'] statement');
                    break;
                }
            }
        }
        finally
        {
            return ($this->db->query('SET FOREIGN_KEY_CHECKS=1')!==false) || $result; 
        }
    }
//=============================================================================
    public function selectOne(string $sql, array $params=[], string $class='') : array|object|false
    {
        if ($this->_execute($sql,$params)) 
        {	
            if ($class)
            {
                $this->stmt->setFetchMode(
                    PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 
                    $class,array_keys(get_class_vars($class))
                );
            }    
            else
            {
                $this->stmt->setFetchMode(PDO::FETCH_ASSOC);
            }
            return $this->stmt->fetch();
        }				
        return false;
    }
//==============================================================================
    public function selectMore(string $sql, array $params=[], string $class='') : array|false
    {
        if ($this->_execute($sql,$params)) 
        {	
            if ($class)
            {
                $this->stmt->setFetchMode(
                    PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 
                    $class,array_keys(get_class_vars($class))
                );
            }    
            else
            {
                $this->stmt->setFetchMode(PDO::FETCH_ASSOC);
            }
            return $this->stmt->fetchAll();
        }	
        return false;
    }
//==============================================================================
// Getting key-value pairs.
// Also extremely useful format, when we need to get the same column, 
// but indexed not by numbers in order but by another field. 
// Here goes PDO::FETCH_KEY_PAIR constant:    
//==============================================================================
    public function selectAsPairs(string $sql, array $params=[]) : array|false
    {
        return $this->_executeAndFetchAll($sql,$params, PDO::FETCH_KEY_PAIR); 
    }
//==============================================================================
// Getting rows indexed by unique field
// Same as above, but getting not one column but full row, 
// yet indexed by an unique field, thanks to PDO::FETCH_UNIQUE constant:
//==============================================================================
    public function selectAsUnique(string $sql, array $params=[]) : array|false
    {
        return $this->_executeAndFetchAll($sql,$params, PDO::FETCH_UNIQUE);
    }
//==============================================================================
// Getting rows grouped by some field
// PDO::FETCH_GROUP will group rows into a nested array,
// where indexes will be unique values from the first column,
// and values will be arrays similar to ones returned by regular fetchAll().
// The following code, for example, will separate boys from girls and put them into different arrays:
// $data = $pdo->query('SELECT sex, name, car FROM users')->fetchAll(PDO::FETCH_GROUP);
/* array (
  'male' => array (
    0 => array (
      'name' => 'John',
      'car' => 'Toyota',
    ),
    1 => array (
      'name' => 'Mike',
      'car' => 'Ford',
    ),
  ),
  'female' => array (...
*/
    public function selectGrouped(string $sql, array $params=[]) : array|false
    {
        return $this->_executeAndFetchAll($sql,$params, PDO::FETCH_GROUP);
    }
//==============================================================================
    public function selectColumn(string $sql, int $column=0, array $params=[]) : array|false
    {
        $this->column = $column;
        return $this->_executeAndFetchAll($sql,$params, PDO::FETCH_COLUMN);
    }    
//==============================================================================
    public function doInsert(string $sql, array $params=[]) : int|false
    {
        if ($this->_execute($sql,$params))
        {
            return $this->db->lastInsertId();
        }
        return false;
    }
//==============================================================================
    public function doUpdate(string $sql, array $params=[]) : int|false
    {
        if ($this->_execute($sql,$params))
        {
            return $this->stmt->rowCount();
        }
        return false;
    }
//==============================================================================
    public function doDelete(string $sql, array $params=[]): int|false
    {
        if ($this->_execute($sql,$params))
        {
            return $this->stmt->rowCount();
        }
        return false;
    }
//==============================================================================
    public function getDBTables() : array |false
    {
        return self::selectMore('SHOW FULL TABLES',[]);
    }
//==============================================================================
    public function getDBPrimaryKeysByTableName(string $tablename) : array |false
    {  
        return $this->selectColumn(
            "SHOW INDEX FROM "
            . filter_var($tablename)
            ." WHERE Key_name ='PRIMARY'",
            4, //= row Column_name
            []
        );
    }    
//==============================================================================
    public function getDBColumnsByTableName(string $tablename) : array |false
    {
        return $this->selectMore('SHOW FIELDS FROM '. filter_var($tablename),[]);
    }
//==============================================================================
    private function _executeAndFetchAll(string $sql, array $params, int $fetch_mode) : array|false
    {
        if ($this->_execute($sql,$params)) 
        {	
//          if  $this->stmt->setFetchMode($fetch_mode);
            return ($fetch_mode ===  PDO::FETCH_COLUMN)
            ? $this->stmt->fetchAll($fetch_mode, $this->column)
            : $this->stmt->fetchAll($fetch_mode);
        }	
        return false;
    }
//==============================================================================
    private function _execute(string $sql, array $params) : bool
    {
        try
        {
            $this->stmt = $this->db->prepare($sql);
            foreach ($params as $name => $info)
            {
                $this->stmt->bindValue(
                        ":".$name, 
                        $info[self::PARAM_VALUE], 
                        $info[self::PARAM_TYPE] ? PDO::PARAM_INT : PDO::PARAM_STR
                );
            }
            return $this->stmt->execute();
        }    
        catch(PDOException $e)
        {
            \ManKind\tools\dev\Logger::_echo('['.$sql.']');
            \ManKind\tools\dev\Logger::_error($e);
            $this->_setLastError($e->getCode().":".$e->getMessage());
            return false;
        }
    }		
//==============================================================================
    private function __construct(?PDO $conn=null) 
    {
//  Set connection to external conn if paased  (f.i. from CliDbApp
        if ($conn)
        {
            $this->db = $conn;
        }  
// Else create a new connection
        else
        {
            $pass = \ManKind\tools\dev\Tools::garble(\Config::PDOPASS, \Config::MYKEY);
            $this->db = new PDO(\Config::PDODRIVER.":host=".\Config::PDOHOST.";dbname=".\Config::PDODATABASE,\Config::PDOUSER,$pass);
            $this->db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
// Return typed colums, not strings
            $this->db->setAttribute(PDO::ATTR_EMULATE_PREPARES,  false);
            $this->db->setAttribute(PDO::ATTR_STRINGIFY_FETCHES, false);
// ToDo wanneer grote datasets verwacht zet op false!
//            $this->db->setAttribute(PDO::MYSQL_ATTR_USE_BUFFERED_QUERY, FALSE);
        }
    }
//==============================================================================

	public function executeQuery(string $sql, array $params=[]) : bool
    {
        if ($this->_execute($sql,$params))
        {
            return true;
        }
        return false;
    }
}
