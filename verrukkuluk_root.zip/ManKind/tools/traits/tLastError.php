<?php
/**
 * Last Error trait
 *
 * @author Geert Weggemans - geert@man-kind.nl
 * @date jan 8 2020
 */
namespace ManKind\tools\traits;
trait tLastError
{
	protected $_lasterror = '';
	
	public function getLastError() : string
	{
		return $this->_lasterror;
	}
	
	protected function _setLastError(string $error)
	{
		$this->_lasterror = $error;
	}
}
