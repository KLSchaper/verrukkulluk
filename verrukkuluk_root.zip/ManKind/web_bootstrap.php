<?php

use ManKind\tools as TOOLS;

define("LOCALTEST", $_ENV["COMPUTERNAME"] === "HP-KOEN");
define("ISWIN", strtoupper(substr(PHP_OS, 0, 3)) === 'WIN');
/**
Load config file 
dev for development, hp running windows 11/apache
acc for acceptation, slice running windows 10/apache
prod for production, Linux Server running Ubuntu/apache
 */

include("./_sys/config/" . (LOCALTEST ? "dev" : (ISWIN ? "acc" : "prod")) . ".php");
TOOLS\dev\ErrorHandler::init();
TOOLS\dev\Logger::init(
    \Config::LOGPATH,
    TOOLS\dev\LogTarget::TO_LOG,
    TOOLS\dev\LogLevel::LVL_ALLWAYS
);
