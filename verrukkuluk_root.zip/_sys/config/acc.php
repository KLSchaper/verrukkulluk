<?php
class Config 
{
    const NOP               = 'NOP';
    const APPTITLE          = 'Verrukkulluk';
    const LINKBASE          = 'http://localhost/verrukkulluk/';
    const DOCROOT           = 'C:\xampp2\htdocs\verrukkulluk\\';
    const HTML              = true;
    const STRICT            = false;
    const AUTHOR            = 'K en K';
    const AUTHOR_URL        = '';

    const USERID            = 'UID';
    const USEREMAIL         = 'UEMAIL';
    const USERNAME          = 'UNAME';
    const USERROLE          = 'UROLE';

    const CART              = 'CART';
    const SYSMSG            = 'SYSMSG';
    const SYSERR            = 'SYSERR';
    const MYKEY             = '4711wwPxTT#^';
    const ASSETS            = self::DOCROOT.'assets\\';
    const LOGPATH           = self::DOCROOT.'_sys\logs\\'; 

    const CACHEPATH         = self::DOCROOT.'_sys\cache\\'; 
    const CACHEEXT          =	'.tmp'; 

    const UPLOADPATH        = self::ASSETS.'shop\\';
    const SHOPIMG_URL       = self::LINKBASE.'assets/shop/';
    const WEBIMG_URL        = self::LINKBASE.'assets/img/';

    const CSS_URL           = self::LINKBASE.'assets/css/';
    const JS_URL            = self::LINKBASE.'assets/js/';

    const SHARED_RES_PATH   ='W:\wwwroot\__educom\__shared\\';
    const SHARED_RES_URL    ='http://educom.local/__shared/';


    const PDODRIVER         = 'mysql';
    const PDOHOST           = 'localhost';
    const PDODATABASE       = 'verrukkulluk';
    const PDOUSER           = 'root';
    const PDOPASS           = false;

    const XML_FILE_PATH     = self::ASSETS.'xml\\';
    const XML_NS_URI        = self::LINKBASE.'xml';
    const XML_NS_PREF       = 'ns1';
    const XML_FILE_URL      = self::LINKBASE.'API/FILE/';
}