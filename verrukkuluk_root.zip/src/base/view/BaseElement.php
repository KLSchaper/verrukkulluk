<?php

namespace vrklk\base\view;

abstract class BaseElement
{
    abstract public function show();
}
