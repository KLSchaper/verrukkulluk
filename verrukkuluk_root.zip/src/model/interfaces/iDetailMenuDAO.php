<?php

namespace vrklk\model\interfaces;

interface iDetailMenuDAO
{
    public function getDetailMenuItems(): array;
}
